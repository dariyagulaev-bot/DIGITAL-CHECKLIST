// VERO desktop shell — a fully offline Windows application.
//
// It loads ONLY the local app bundle (resources/VERO.html) and nothing else:
//   • no network access, no external URL, no localhost, no auto-update;
//   • VERO renders inside Electron's own bundled Chromium (ships with the app);
//   • all navigation away from the local file and all new windows are blocked;
//   • all runtime permission requests (camera, mic, geolocation, …) are denied.
//
// User data (IndexedDB: forms, signatures, images, users, certifications,
// exams) is stored permanently under the app's userData folder
// (%APPDATA%\VERO on Windows) and survives restarts and updates.

const { app, BrowserWindow, Menu, session } = require('electron');
const path = require('path');

// Give the app (and its userData folder) a stable name: %APPDATA%\VERO.
app.setName('VERO');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  let win = null;

  function createWindow() {
    win = new BrowserWindow({
      width: 1280,
      height: 800,
      show: false,
      backgroundColor: '#0f2b52',
      autoHideMenuBar: true,
      icon: path.join(__dirname, 'icon.png'), // window + taskbar icon (VERO logo)
      webPreferences: {
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
        spellcheck: false,
        devTools: false,
        webviewTag: false,
      },
    });

    Menu.setApplicationMenu(null);
    win.loadFile(path.join(__dirname, 'resources', 'VERO.html'));
    win.once('ready-to-show', () => {
      win.maximize();
      win.show();
    });

    // Block ANY navigation away from the local bundle and any popup/new window.
    win.webContents.on('will-navigate', (e) => e.preventDefault());
    win.webContents.on('will-redirect', (e) => e.preventDefault());
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  }

  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });

  app.whenReady().then(() => {
    session.defaultSession.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));
    session.defaultSession.setPermissionCheckHandler(() => false);
    createWindow();
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });

  app.on('window-all-closed', () => app.quit());
}
